export interface Product {
  id: string;
  name: string;
  shortDescription: string;
  description: string;
  price: number;
  image: string;
  category: string;
  features: string[];
  specifications: {
    [key: string]: string;
  };
  relatedProducts?: string[];
}

export interface BlogPost {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  imageUrl: string;
  date: string;
  author: string;
  category: string;
}