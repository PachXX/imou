import React from 'react';
import { Link } from 'react-router-dom';
import { Shield, Home, Building, Trophy, Users, GraduationCap } from 'lucide-react';

const AboutPage: React.FC = () => {
  return (
    <div>
      <div className="bg-gradient-to-r from-blue-900 to-blue-700 py-12">
        <div className="container-custom">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-4">About IMOU</h1>
          <div className="flex items-center text-blue-100">
            <Link to="/" className="hover:text-white">Home</Link>
            <span className="mx-2">/</span>
            <span className="text-white">About Us</span>
          </div>
        </div>
      </div>

      <section className="py-16">
        <div className="container-custom">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="md:w-1/2">
              <img 
                src="https://images.pexels.com/photos/3205570/pexels-photo-3205570.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="IMOU Office" 
                className="rounded-lg shadow-xl w-full"
              />
            </div>
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold mb-6">Our Story</h2>
              <p className="text-gray-700 mb-4">
                Founded in 2012, IMOU has grown from a small tech startup to a global leader in smart security solutions. Our mission is to make advanced security technology accessible to everyone, providing peace of mind to homeowners and businesses worldwide.
              </p>
              <p className="text-gray-700 mb-4">
                With a team of dedicated engineers and security experts, we've developed a comprehensive lineup of intelligent security cameras and systems that combine cutting-edge technology with user-friendly design.
              </p>
              <p className="text-gray-700">
                Today, IMOU products protect millions of homes and businesses across 83 countries. We continue to innovate, pushing the boundaries of what's possible in smart security while maintaining our commitment to quality, reliability, and customer satisfaction.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-50">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Our Values</h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              At the core of everything we do are these guiding principles that shape our products, services, and customer relationships.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-lg shadow-md text-center">
              <div className="bg-blue-100 rounded-full p-4 w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                <Shield className="w-8 h-8 text-[#0066cc]" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Security & Privacy</h3>
              <p className="text-gray-600">
                We prioritize the protection of our customers' data and privacy in everything we design and build.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-lg shadow-md text-center">
              <div className="bg-blue-100 rounded-full p-4 w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                <GraduationCap className="w-8 h-8 text-[#0066cc]" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Innovation</h3>
              <p className="text-gray-600">
                We continuously explore new technologies to enhance our products and stay ahead of security threats.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-lg shadow-md text-center">
              <div className="bg-blue-100 rounded-full p-4 w-16 h-16 mx-auto mb-6 flex items-center justify-center">
                <Users className="w-8 h-8 text-[#0066cc]" />
              </div>
              <h3 className="text-xl font-semibold mb-3">Customer First</h3>
              <p className="text-gray-600">
                We design our products with real-world customer needs in mind and provide exceptional support.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Our Milestones</h2>
            <p className="text-gray-600 max-w-3xl mx-auto">
              Key moments in our journey to becoming a global leader in smart security solutions.
            </p>
          </div>
          
          <div className="space-y-8">
            <div className="flex flex-col md:flex-row">
              <div className="md:w-1/4 mb-4 md:mb-0">
                <div className="flex flex-col items-center md:items-end md:pr-8">
                  <div className="text-2xl font-bold text-[#0066cc]">2012</div>
                  <div className="hidden md:block w-8 h-1 bg-[#0066cc] mt-2"></div>
                </div>
              </div>
              <div className="md:w-3/4 md:border-l md:border-gray-200 md:pl-8 pb-8">
                <h3 className="text-xl font-semibold mb-2">Company Founded</h3>
                <p className="text-gray-600">IMOU is established with a vision to create accessible security technology.</p>
              </div>
            </div>
            
            <div className="flex flex-col md:flex-row">
              <div className="md:w-1/4 mb-4 md:mb-0">
                <div className="flex flex-col items-center md:items-end md:pr-8">
                  <div className="text-2xl font-bold text-[#0066cc]">2015</div>
                  <div className="hidden md:block w-8 h-1 bg-[#0066cc] mt-2"></div>
                </div>
              </div>
              <div className="md:w-3/4 md:border-l md:border-gray-200 md:pl-8 pb-8">
                <h3 className="text-xl font-semibold mb-2">First Product Line</h3>
                <p className="text-gray-600">Launch of our first generation of Wi-Fi enabled security cameras.</p>
              </div>
            </div>
            
            <div className="flex flex-col md:flex-row">
              <div className="md:w-1/4 mb-4 md:mb-0">
                <div className="flex flex-col items-center md:items-end md:pr-8">
                  <div className="text-2xl font-bold text-[#0066cc]">2018</div>
                  <div className="hidden md:block w-8 h-1 bg-[#0066cc] mt-2"></div>
                </div>
              </div>
              <div className="md:w-3/4 md:border-l md:border-gray-200 md:pl-8 pb-8">
                <h3 className="text-xl font-semibold mb-2">International Expansion</h3>
                <p className="text-gray-600">IMOU products become available in over 30 countries worldwide.</p>
              </div>
            </div>
            
            <div className="flex flex-col md:flex-row">
              <div className="md:w-1/4 mb-4 md:mb-0">
                <div className="flex flex-col items-center md:items-end md:pr-8">
                  <div className="text-2xl font-bold text-[#0066cc]">2020</div>
                  <div className="hidden md:block w-8 h-1 bg-[#0066cc] mt-2"></div>
                </div>
              </div>
              <div className="md:w-3/4 md:border-l md:border-gray-200 md:pl-8 pb-8">
                <h3 className="text-xl font-semibold mb-2">AI Technology Integration</h3>
                <p className="text-gray-600">Introduction of advanced AI-powered features in our security cameras.</p>
              </div>
            </div>
            
            <div className="flex flex-col md:flex-row">
              <div className="md:w-1/4 mb-4 md:mb-0">
                <div className="flex flex-col items-center md:items-end md:pr-8">
                  <div className="text-2xl font-bold text-[#0066cc]">2023</div>
                  <div className="hidden md:block w-8 h-1 bg-[#0066cc] mt-2"></div>
                </div>
              </div>
              <div className="md:w-3/4 md:border-l md:border-gray-200 md:pl-8">
                <h3 className="text-xl font-semibold mb-2">10 Million Users Milestone</h3>
                <p className="text-gray-600">IMOU celebrates reaching 10 million active users globally.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-[#0066cc] text-white">
        <div className="container-custom">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Our Global Presence</h2>
            <p className="text-blue-100 max-w-3xl mx-auto">
              IMOU products protect homes and businesses across the globe.
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold mb-2">83</div>
              <div className="text-blue-100">Countries</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">10M+</div>
              <div className="text-blue-100">Active Users</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">500+</div>
              <div className="text-blue-100">Employees</div>
            </div>
            <div>
              <div className="text-4xl font-bold mb-2">15+</div>
              <div className="text-blue-100">Product Lines</div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16">
        <div className="container-custom">
          <div className="flex flex-col md:flex-row items-center gap-12">
            <div className="md:w-1/2">
              <h2 className="text-3xl font-bold mb-6">Join Our Team</h2>
              <p className="text-gray-700 mb-4">
                At IMOU, we're always looking for talented individuals who share our passion for innovation and security. We offer a dynamic work environment where creativity is encouraged and professional growth is supported.
              </p>
              <p className="text-gray-700 mb-6">
                Our diverse team brings together experts from various fields, including engineering, design, security, and customer support, all working together to create exceptional products.
              </p>
              <Link to="/careers" className="btn-primary">View Open Positions</Link>
            </div>
            <div className="md:w-1/2">
              <img 
                src="https://images.pexels.com/photos/3184302/pexels-photo-3184302.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" 
                alt="IMOU Team" 
                className="rounded-lg shadow-xl w-full"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;