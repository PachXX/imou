import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import ProductCard from '../components/ProductCard';
import { products } from '../data/products';

const categories = [
  { id: 'all', name: 'All Products' },
  { id: 'indoor', name: 'Indoor Cameras' },
  { id: 'outdoor', name: 'Outdoor Cameras' },
  { id: 'accessories', name: 'Accessories' }
];

const ProductsPage: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState('all');
  const [sortBy, setSortBy] = useState('featured');
  
  let filteredProducts = activeCategory === 'all' 
    ? products 
    : products.filter(product => product.category === activeCategory);

  // Sort products based on selected criteria
  filteredProducts = [...filteredProducts].sort((a, b) => {
    switch (sortBy) {
      case 'price-low':
        return a.price - b.price;
      case 'price-high':
        return b.price - a.price;
      case 'newest':
        return -1; // Assuming newest first
      default:
        return 0; // Keep original order for featured
    }
  });

  return (
    <div>
      <div className="bg-gradient-to-r from-blue-900 to-blue-700 py-12">
        <div className="container-custom">
          <h1 className="text-3xl md:text-4xl font-bold text-white mb-4">Our Products</h1>
          <div className="flex items-center text-blue-100">
            <Link to="/" className="hover:text-white">Home</Link>
            <span className="mx-2">/</span>
            <span className="text-white">Products</span>
          </div>
        </div>
      </div>

      <section className="py-12">
        <div className="container-custom">
          <div className="flex flex-col md:flex-row gap-8">
            <div className="md:w-1/4">
              <div className="bg-white shadow-md rounded-lg p-6">
                <h2 className="text-xl font-bold mb-4">Categories</h2>
                <ul className="space-y-2">
                  {categories.map((category) => (
                    <li key={category.id}>
                      <button
                        onClick={() => setActiveCategory(category.id)}
                        className={`w-full text-left px-2 py-2 rounded transition ${
                          activeCategory === category.id
                            ? 'bg-blue-100 text-[#0066cc] font-medium'
                            : 'hover:bg-gray-100'
                        }`}
                      >
                        {category.name}
                      </button>
                    </li>
                  ))}
                </ul>

                <div className="mt-8">
                  <h2 className="text-xl font-bold mb-4">Need Help?</h2>
                  <p className="text-gray-600 mb-4">
                    Not sure which product is right for you? Our experts are here to help.
                  </p>
                  <Link 
                    to="/support/contact" 
                    className="bg-[#0066cc] text-white py-2 px-4 rounded-md hover:bg-blue-700 transition-colors w-full block text-center"
                  >
                    Contact Support
                  </Link>
                </div>
              </div>
            </div>

            <div className="md:w-3/4">
              <div className="mb-6 flex flex-col sm:flex-row justify-between items-start sm:items-center">
                <h2 className="text-2xl font-semibold mb-2 sm:mb-0">
                  {categories.find(c => c.id === activeCategory)?.name} 
                  <span className="text-gray-500 text-lg ml-2">({filteredProducts.length})</span>
                </h2>
                <div className="w-full sm:w-auto">
                  <select 
                    className="w-full sm:w-auto px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                  >
                    <option value="featured">Featured</option>
                    <option value="newest">Newest</option>
                    <option value="price-low">Price: Low to High</option>
                    <option value="price-high">Price: High to Low</option>
                  </select>
                </div>
              </div>

              {filteredProducts.length === 0 ? (
                <div className="text-center py-12 bg-gray-50 rounded-lg">
                  <p className="text-xl text-gray-600">No products found in this category.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredProducts.map((product) => (
                    <ProductCard key={product.id} product={product} />
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ProductsPage;