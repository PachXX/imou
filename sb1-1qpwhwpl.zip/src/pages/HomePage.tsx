import React from 'react';
import Hero from '../components/Hero';
import FeaturedCategories from '../components/FeaturedCategories';
import Features from '../components/Features';
import ProductCard from '../components/ProductCard';
import BlogCard from '../components/BlogCard';
import { getFeaturedProducts } from '../data/products';
import { getLatestBlogPosts } from '../data/blog';

const HomePage: React.FC = () => {
  const featuredProducts = getFeaturedProducts();
  const latestPosts = getLatestBlogPosts(3);

  return (
    <div>
      <Hero 
        title="Smart Security for Your Peace of Mind"
        subtitle="Advanced security cameras with AI detection, clear night vision, and mobile monitoring to protect what matters most."
        imageUrl="https://images.pexels.com/photos/3587478/pexels-photo-3587478.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
        buttonText="Explore Products"
        buttonLink="/products"
      />

      <Features />

      <section className="py-12 bg-white">
        <div className="container-custom">
          <h2 className="section-title">Featured Products</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
          <div className="text-center mt-10">
            <a href="/products" className="btn-primary">View All Products</a>
          </div>
        </div>
      </section>

      <FeaturedCategories />

      <section className="py-16 bg-gradient-to-r from-blue-900 to-blue-700 text-white">
        <div className="container-custom">
          <div className="flex flex-col md:flex-row items-center">
            <div className="md:w-1/2 mb-8 md:mb-0">
              <img 
                src="https://images.pexels.com/photos/821754/pexels-photo-821754.jpeg?auto=compress&cs=tinysrgb&w=600" 
                alt="IMOU App" 
                className="rounded-lg shadow-xl w-full"
              />
            </div>
            <div className="md:w-1/2 md:pl-12">
              <h2 className="text-3xl font-bold mb-4">Control Your Security from Anywhere</h2>
              <p className="text-lg text-blue-100 mb-6">
                With the IMOU app, you can monitor your home or business from anywhere in the world. Receive real-time alerts, watch live feeds, and control your cameras all from your smartphone.
              </p>
              <ul className="space-y-4 mb-8">
                <li className="flex items-start">
                  <div className="bg-blue-100 rounded-full p-1 mt-1 mr-3">
                    <svg className="w-4 h-4 text-blue-700" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <span>Real-time notifications when motion is detected</span>
                </li>
                <li className="flex items-start">
                  <div className="bg-blue-100 rounded-full p-1 mt-1 mr-3">
                    <svg className="w-4 h-4 text-blue-700" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <span>Two-way audio to communicate through your camera</span>
                </li>
                <li className="flex items-start">
                  <div className="bg-blue-100 rounded-full p-1 mt-1 mr-3">
                    <svg className="w-4 h-4 text-blue-700" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <span>Playback and save footage directly to your device</span>
                </li>
              </ul>
              <a href="#" className="btn-primary bg-[#ff6600] hover:bg-orange-600">Download App</a>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12 bg-gray-50">
        <div className="container-custom">
          <h2 className="section-title">Latest from Our Blog</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-8">
            {latestPosts.map((post) => (
              <BlogCard key={post.id} post={post} />
            ))}
          </div>
          <div className="text-center mt-10">
            <a href="/blog" className="btn-secondary">View All Posts</a>
          </div>
        </div>
      </section>

      <section className="py-16 bg-white">
        <div className="container-custom text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to Secure Your Space?</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto mb-8">
            Discover our wide range of security solutions and find the perfect fit for your home or business.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <a href="/products" className="btn-primary">Shop Now</a>
            <a href="/support/contact" className="btn-secondary">Contact Us</a>
          </div>
        </div>
      </section>
    </div>
  );
};

export default HomePage;