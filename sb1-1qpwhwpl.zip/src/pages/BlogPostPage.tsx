import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { getBlogPostById, getLatestBlogPosts } from '../data/blog';
import { Calendar, User, Tag } from 'lucide-react';
import BlogCard from '../components/BlogCard';

const BlogPostPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const post = id ? getBlogPostById(id) : undefined;
  const relatedPosts = getLatestBlogPosts(3).filter(p => p.id !== id);

  if (!post) {
    return (
      <div className="container-custom py-20 text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Article Not Found</h2>
        <p className="text-gray-600 mb-8">The article you're looking for doesn't exist or has been removed.</p>
        <Link to="/blog" className="btn-primary">Back to Blog</Link>
      </div>
    );
  }

  return (
    <div>
      <div className="bg-gradient-to-r from-blue-900 to-blue-700 py-8">
        <div className="container-custom">
          <div className="flex items-center text-blue-100">
            <Link to="/" className="hover:text-white">Home</Link>
            <span className="mx-2">/</span>
            <Link to="/blog" className="hover:text-white">Blog</Link>
            <span className="mx-2">/</span>
            <span className="text-white truncate max-w-[200px] md:max-w-xs">{post.title}</span>
          </div>
        </div>
      </div>

      <article className="py-12">
        <div className="container-custom max-w-4xl">
          <img 
            src={post.imageUrl} 
            alt={post.title} 
            className="w-full h-[400px] object-cover rounded-xl mb-8"
          />

          <h1 className="text-3xl md:text-4xl font-bold mb-4">{post.title}</h1>
          
          <div className="flex flex-wrap items-center text-gray-600 mb-8">
            <div className="flex items-center mr-6 mb-2">
              <Calendar size={16} className="mr-2" />
              <span>{post.date}</span>
            </div>
            <div className="flex items-center mr-6 mb-2">
              <User size={16} className="mr-2" />
              <span>{post.author}</span>
            </div>
            <div className="flex items-center mb-2">
              <Tag size={16} className="mr-2" />
              <span>{post.category}</span>
            </div>
          </div>

          <div className="prose prose-lg max-w-none">
            {post.content.split('\n').map((paragraph, idx) => {
              if (paragraph.startsWith('# ')) {
                return <h1 key={idx} className="text-3xl font-bold my-6">{paragraph.substring(2)}</h1>;
              } else if (paragraph.startsWith('## ')) {
                return <h2 key={idx} className="text-2xl font-semibold my-5">{paragraph.substring(3)}</h2>;
              } else if (paragraph.startsWith('### ')) {
                return <h3 key={idx} className="text-xl font-semibold my-4">{paragraph.substring(4)}</h3>;
              } else if (paragraph.startsWith('- ')) {
                return <li key={idx} className="ml-6 my-2">{paragraph.substring(2)}</li>;
              } else if (paragraph.trim() === '') {
                return <br key={idx} />;
              } else {
                return <p key={idx} className="my-4 text-gray-700 leading-relaxed">{paragraph}</p>;
              }
            })}
          </div>

          <div className="mt-12 pt-8 border-t">
            <div className="flex flex-wrap gap-2">
              <span className="font-semibold">Share:</span>
              <a href="#" className="text-[#0066cc] hover:underline">Facebook</a>
              <span className="text-gray-400">•</span>
              <a href="#" className="text-[#0066cc] hover:underline">Twitter</a>
              <span className="text-gray-400">•</span>
              <a href="#" className="text-[#0066cc] hover:underline">LinkedIn</a>
            </div>
          </div>
        </div>
      </article>

      <section className="py-12 bg-gray-50">
        <div className="container-custom">
          <h2 className="text-2xl font-bold mb-8">Related Articles</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {relatedPosts.map((post) => (
              <BlogCard key={post.id} post={post} />
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default BlogPostPage;