import React, { useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getProductById, getRelatedProducts } from '../data/products';
import ProductCard from '../components/ProductCard';
import { ShoppingCart, Check } from 'lucide-react';

const ProductDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const [activeTab, setActiveTab] = useState('features');
  const [quantity, setQuantity] = useState(1);

  const product = id ? getProductById(id) : undefined;
  const relatedProducts = id ? getRelatedProducts(id) : [];

  if (!product) {
    return (
      <div className="container-custom py-20 text-center">
        <h2 className="text-2xl font-bold text-gray-800 mb-4">Product Not Found</h2>
        <p className="text-gray-600 mb-8">The product you're looking for doesn't exist or has been removed.</p>
        <Link to="/products" className="btn-primary">Browse All Products</Link>
      </div>
    );
  }

  return (
    <div>
      <div className="bg-gradient-to-r from-blue-900 to-blue-700 py-8">
        <div className="container-custom">
          <div className="flex items-center text-blue-100">
            <Link to="/" className="hover:text-white">Home</Link>
            <span className="mx-2">/</span>
            <Link to="/products" className="hover:text-white">Products</Link>
            <span className="mx-2">/</span>
            <span className="text-white">{product.name}</span>
          </div>
        </div>
      </div>

      <section className="py-12">
        <div className="container-custom">
          <div className="flex flex-col lg:flex-row gap-12">
            {/* Product Image */}
            <div className="lg:w-1/2">
              <div className="bg-white p-6 rounded-lg shadow-md">
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="w-full h-auto object-contain"
                />
              </div>
            </div>

            {/* Product Info */}
            <div className="lg:w-1/2">
              <h1 className="text-3xl font-bold mb-2">{product.name}</h1>
              <p className="text-xl text-gray-700 mb-4">{product.shortDescription}</p>
              
              <div className="mb-6">
                <span className="text-2xl font-bold text-[#0066cc]">${product.price.toFixed(2)}</span>
                <span className="text-green-600 ml-2">In Stock</span>
              </div>

              <p className="text-gray-700 mb-6">
                {product.description}
              </p>

              <div className="flex flex-col sm:flex-row items-center gap-4 mb-8">
                <div className="flex border rounded-md">
                  <button 
                    className="px-4 py-2 border-r"
                    onClick={() => setQuantity(prev => Math.max(1, prev - 1))}
                  >
                    -
                  </button>
                  <span className="px-6 py-2">{quantity}</span>
                  <button 
                    className="px-4 py-2 border-l"
                    onClick={() => setQuantity(prev => prev + 1)}
                  >
                    +
                  </button>
                </div>
                <button className="bg-[#0066cc] text-white py-3 px-8 rounded-md hover:bg-blue-700 transition-colors flex items-center justify-center w-full sm:w-auto">
                  <ShoppingCart size={20} className="mr-2" />
                  Add to Cart
                </button>
              </div>

              <div className="border-t pt-6">
                <h3 className="text-lg font-semibold mb-3">Key Features:</h3>
                <ul className="space-y-2">
                  {product.features.slice(0, 4).map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <Check size={18} className="text-green-500 mr-2 mt-1 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>

          {/* Tabs */}
          <div className="mt-16">
            <div className="border-b">
              <div className="flex flex-wrap">
                <button 
                  className={`px-6 py-3 font-medium ${activeTab === 'features' ? 'border-b-2 border-[#0066cc] text-[#0066cc]' : 'text-gray-600'}`}
                  onClick={() => setActiveTab('features')}
                >
                  Features & Specifications
                </button>
                <button 
                  className={`px-6 py-3 font-medium ${activeTab === 'specs' ? 'border-b-2 border-[#0066cc] text-[#0066cc]' : 'text-gray-600'}`}
                  onClick={() => setActiveTab('specs')}
                >
                  Technical Specifications
                </button>
              </div>
            </div>

            <div className="py-8">
              {activeTab === 'features' && (
                <div>
                  <h3 className="text-xl font-semibold mb-4">Features</h3>
                  <ul className="space-y-4">
                    {product.features.map((feature, index) => (
                      <li key={index} className="flex items-start">
                        <Check size={20} className="text-green-500 mr-3 mt-1 flex-shrink-0" />
                        <span>{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              {activeTab === 'specs' && (
                <div>
                  <h3 className="text-xl font-semibold mb-4">Technical Specifications</h3>
                  <div className="overflow-x-auto">
                    <table className="min-w-full divide-y divide-gray-200">
                      <tbody className="divide-y divide-gray-200">
                        {Object.entries(product.specifications).map(([key, value], index) => (
                          <tr key={index} className={index % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 w-1/3">
                              {key}
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                              {value}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Related Products */}
          {relatedProducts.length > 0 && (
            <div className="mt-16">
              <h2 className="text-2xl font-semibold mb-6">Related Products</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                {relatedProducts.map((product) => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </div>
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default ProductDetailPage;