import { Product } from '../types';

export const products: Product[] = [
  {
    id: 'cruiser-2',
    name: 'Cruiser 2',
    shortDescription: '2K Motorized Outdoor Wi-Fi Camera',
    description: 'Cruiser 2 provides superior 2K resolution with color night vision and AI human detection. Its motorized pan and tilt capabilities offer 360° coverage, providing comprehensive protection for your outdoor spaces.',
    price: 149.99,
    image: 'https://www.imou.com/de/public/upload/product/Cruiser2/Cruiser2_01.png',
    category: 'outdoor',
    features: [
      '2K Resolution (2560 × 1440)',
      '360° Pan & Tilt Coverage',
      'Active Deterrence with Siren & Spotlight',
      'Color Night Vision',
      'AI Human Detection',
      'Two-Way Talk',
      'IP66 Weather Resistance'
    ],
    specifications: {
      'Image Sensor': '1/2.7" Progressive CMOS',
      'Resolution': '2K (2560 × 1440)',
      'Lens': '4mm@F1.0',
      'Night Vision': 'Up to 30m (98ft)',
      'Audio': 'Built-in Mic and Speaker',
      'Storage': 'MicroSD Card (up to 256GB) / Cloud Storage',
      'Wi-Fi': 'IEEE802.11b/g/n 2.4GHz',
      'Operating Temperature': '-10°C to 45°C (14°F to 113°F)',
      'Power Supply': 'DC 12V 1A',
      'Dimensions': '108 × 108 × 190.5mm (4.3 × 4.3 × 7.5in)'
    },
    relatedProducts: ['ranger-2', 'bullet-2', 'rex-3']
  },
  {
    id: 'ranger-2',
    name: 'Ranger 2C',
    shortDescription: '1080P Outdoor Wi-Fi Camera with Spotlight',
    description: 'The Ranger 2C offers crystal-clear 1080P video with an integrated spotlight for color night vision. With AI-powered human detection and active deterrence features, it provides exceptional security for any outdoor area.',
    price: 89.99,
    image: 'https://www.imou.com/de/public/upload/product/Ranger2C/Ranger2C_01.png',
    category: 'outdoor',
    features: [
      '1080P Resolution',
      'Built-in Spotlight',
      'Color Night Vision',
      'AI Human Detection',
      'Active Deterrence with Siren',
      'Two-Way Talk',
      'IP67 Weather Resistance'
    ],
    specifications: {
      'Image Sensor': '1/2.7" Progressive CMOS',
      'Resolution': '1080P',
      'Lens': '3.6mm@F1.6',
      'Night Vision': 'Up to 30m (98ft)',
      'Audio': 'Built-in Mic and Speaker',
      'Storage': 'MicroSD Card (up to 256GB) / Cloud Storage',
      'Wi-Fi': 'IEEE802.11b/g/n 2.4GHz',
      'Operating Temperature': '-30°C to 60°C (-22°F to 140°F)',
      'Power Supply': 'DC 12V 1A',
      'Dimensions': '72 × 72 × 150mm (2.8 × 2.8 × 5.9in)'
    }
  },
  {
    id: 'rex-3',
    name: 'Rex 3',
    shortDescription: '2K Indoor Pan & Tilt Wi-Fi Camera',
    description: 'Rex 3 is an advanced indoor security camera featuring 2K resolution and 360° pan and tilt coverage. With AI-powered person detection and privacy mode, it offers comprehensive indoor monitoring with enhanced smart features.',
    price: 99.99,
    image: 'https://www.imou.com/de/public/upload/product/Rex3/Rex3_01.png',
    category: 'indoor',
    features: [
      '2K Resolution (2560 × 1440)',
      '360° Pan & Tilt Coverage',
      'AI Person Detection',
      'Privacy Mode',
      'Two-Way Talk',
      'Night Vision',
      'Works with Alexa & Google Assistant'
    ],
    specifications: {
      'Image Sensor': '1/2.8" Progressive CMOS',
      'Resolution': '2K (2560 × 1440)',
      'Lens': '4mm@F1.6',
      'Pan/Tilt': 'Pan: 0°~355°, Tilt: -5°~80°',
      'Night Vision': 'Up to 10m (33ft)',
      'Audio': 'Built-in Mic and Speaker',
      'Storage': 'MicroSD Card (up to 256GB) / Cloud Storage',
      'Wi-Fi': 'IEEE802.11b/g/n 2.4GHz',
      'Power Supply': 'DC 5V 1A',
      'Dimensions': '87 × 87 × 114mm (3.4 × 3.4 × 4.5in)'
    }
  },
  {
    id: 'knight-2c',
    name: 'Knight 2C',
    shortDescription: '2K Indoor Pan & Tilt Wi-Fi Camera',
    description: 'The Knight 2C delivers crystal clear 2K video with advanced pan and tilt capabilities. Perfect for indoor monitoring with AI-powered detection and smart tracking features.',
    price: 79.99,
    image: 'https://www.imou.com/de/public/upload/product/Knight2C/Knight2C_01.png',
    category: 'indoor',
    features: [
      '2K Resolution',
      'Pan & Tilt',
      'Smart Tracking',
      'AI Detection',
      'Two-Way Audio',
      'Night Vision',
      'MicroSD & Cloud Storage'
    ],
    specifications: {
      'Image Sensor': '1/2.7" CMOS',
      'Resolution': '2K (2560 × 1440)',
      'Lens': '3.6mm@F2.0',
      'Night Vision': 'Up to 10m',
      'Audio': 'Two-way audio',
      'Storage': 'MicroSD Card (up to 256GB)',
      'Wi-Fi': '2.4GHz',
      'Power': 'DC 5V 1A',
      'Dimensions': '85 × 85 × 118mm'
    }
  },
  {
    id: 'bullet-lite-4mp',
    name: 'Bullet Lite 4MP',
    shortDescription: '4MP Outdoor Wi-Fi Camera',
    description: 'The Bullet Lite 4MP offers high-resolution surveillance with advanced night vision and weather resistance, perfect for outdoor security.',
    price: 69.99,
    image: 'https://www.imou.com/de/public/upload/product/BulletLite4MP/BulletLite4MP_01.png',
    category: 'outdoor',
    features: [
      '4MP Resolution',
      'Night Vision',
      'IP67 Weatherproof',
      'Motion Detection',
      'H.265 Compression',
      'Two-Way Audio',
      'Cloud Storage'
    ],
    specifications: {
      'Image Sensor': '1/3" Progressive CMOS',
      'Resolution': '4MP (2688 × 1520)',
      'Lens': '2.8mm@F2.0',
      'Night Vision': '30m',
      'Protection': 'IP67',
      'Storage': 'MicroSD/Cloud',
      'Wi-Fi': '2.4GHz',
      'Power': 'DC 12V 1A',
      'Dimensions': '70 × 70 × 137mm'
    }
  },
  {
    id: 'cube-se',
    name: 'Cube SE',
    shortDescription: '1080P Indoor Wi-Fi Camera',
    description: 'The Cube SE is a compact and versatile indoor camera offering 1080P resolution and smart features at an affordable price.',
    price: 29.99,
    image: 'https://www.imou.com/de/public/upload/product/CubeSE/CubeSE_01.png',
    category: 'indoor',
    features: [
      '1080P Resolution',
      'Night Vision',
      'Motion Detection',
      'Two-Way Audio',
      'Privacy Mode',
      'MicroSD Storage',
      'Easy Setup'
    ],
    specifications: {
      'Image Sensor': '1/2.9" CMOS',
      'Resolution': '1080P',
      'Lens': '2.8mm@F2.0',
      'Night Vision': '10m',
      'Audio': 'Two-way audio',
      'Storage': 'MicroSD up to 256GB',
      'Wi-Fi': '2.4GHz',
      'Power': 'DC 5V 1A',
      'Dimensions': '62 × 62 × 108mm'
    }
  }
];

export const getProductById = (id: string): Product | undefined => {
  return products.find(product => product.id === id);
};

export const getProductsByCategory = (category: string): Product[] => {
  return products.filter(product => product.category === category);
};

export const getFeaturedProducts = (): Product[] => {
  return products.slice(0, 4);
};

export const getRelatedProducts = (productId: string): Product[] => {
  const product = getProductById(productId);
  if (!product || !product.relatedProducts) return [];
  
  return product.relatedProducts
    .map(id => getProductById(id))
    .filter((product): product is Product => !!product);
};