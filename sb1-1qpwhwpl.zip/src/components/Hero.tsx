import React from 'react';
import { Link } from 'react-router-dom';

interface HeroProps {
  title: string;
  subtitle: string;
  buttonText: string;
  buttonLink: string;
}

const Hero: React.FC<HeroProps> = ({ 
  title, 
  subtitle, 
  buttonText, 
  buttonLink 
}) => {
  return (
    <div className="relative bg-gradient-to-r from-blue-900 to-blue-700 text-white">
      <div className="container-custom py-16 md:py-24">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-8 md:mb-0 md:pr-12">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4">
              {title}
            </h1>
            <p className="text-lg md:text-xl text-blue-100 mb-8">
              {subtitle}
            </p>
            <Link 
              to={buttonLink} 
              className="inline-block bg-[#ff6600] hover:bg-orange-600 text-white font-medium py-3 px-8 rounded-md transition-colors"
            >
              {buttonText}
            </Link>
          </div>
          <div className="md:w-1/2">
            <img 
              src="https://raw.githubusercontent.com/yourusername/imou-website/main/camera3.jpg" 
              alt="IMOU Smart Security Camera" 
              className="w-full rounded-lg shadow-xl"
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;