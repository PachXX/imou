import React from 'react';
import { Shield, Wifi, Smartphone, Clock } from 'lucide-react';

const features = [
  {
    id: 1,
    title: 'Advanced Security',
    description: 'State-of-the-art encryption and privacy protection for your security footage.',
    icon: <Shield className="w-10 h-10 text-[#0066cc]" />
  },
  {
    id: 2,
    title: 'Smart Wi-Fi Connection',
    description: 'Easy setup with stable and reliable Wi-Fi connection to your home network.',
    icon: <Wifi className="w-10 h-10 text-[#0066cc]" />
  },
  {
    id: 3,
    title: 'Mobile Control',
    description: 'Monitor your home or business from anywhere with our mobile app.',
    icon: <Smartphone className="w-10 h-10 text-[#0066cc]" />
  },
  {
    id: 4,
    title: '24/7 Monitoring',
    description: 'Continuous recording and real-time alerts for round-the-clock protection.',
    icon: <Clock className="w-10 h-10 text-[#0066cc]" />
  }
];

const Features: React.FC = () => {
  return (
    <section className="py-16 bg-white">
      <div className="container-custom">
        <h2 className="section-title">Why Choose IMOU</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mt-8">
          {features.map((feature) => (
            <div key={feature.id} className="text-center p-6 bg-[#eef7ff] rounded-lg hover:shadow-md transition-shadow duration-300">
              <div className="mx-auto mb-4">{feature.icon}</div>
              <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
              <p className="text-gray-600">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;