import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, ShoppingCart, Menu, X, ChevronDown } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isProductsOpen, setIsProductsOpen] = useState(false);
  
  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container-custom py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center">
            <img 
              src="https://raw.githubusercontent.com/yourusername/imou-website/main/logo.png" 
              alt="IMOU" 
              className="h-8"
              style={{ color: '#ff6600' }}
            />
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <div className="relative group">
              <button 
                className="nav-link flex items-center"
                onClick={() => setIsProductsOpen(!isProductsOpen)}
              >
                Products <ChevronDown size={16} className="ml-1" />
              </button>
              <div className={`absolute top-full left-0 bg-white shadow-lg rounded-md py-4 w-48 transition-all duration-200 ${isProductsOpen ? 'opacity-100' : 'opacity-0 invisible'}`}>
                <Link to="/products/indoor" className="block px-4 py-2 hover:bg-blue-50">Indoor Cameras</Link>
                <Link to="/products/outdoor" className="block px-4 py-2 hover:bg-blue-50">Outdoor Cameras</Link>
                <Link to="/products/accessories" className="block px-4 py-2 hover:bg-blue-50">Accessories</Link>
              </div>
            </div>
            <Link to="/about" className="nav-link">About Us</Link>
            <Link to="/blog" className="nav-link">Blog</Link>
            <Link to="/support" className="nav-link">Support</Link>
          </nav>

          {/* Search and Cart */}
          <div className="flex items-center space-x-4">
            <button className="nav-link">
              <Search size={20} />
            </button>
            <Link to="/cart" className="nav-link">
              <ShoppingCart size={20} />
            </Link>
            <button 
              className="md:hidden nav-link"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        <div className={`md:hidden transition-all duration-300 overflow-hidden ${isMenuOpen ? 'max-h-96' : 'max-h-0'}`}>
          <nav className="flex flex-col space-y-4 py-4">
            <button 
              className="nav-link flex items-center justify-between"
              onClick={() => setIsProductsOpen(!isProductsOpen)}
            >
              Products <ChevronDown size={16} className={`transform transition-transform ${isProductsOpen ? 'rotate-180' : ''}`} />
            </button>
            
            <div className={`pl-4 space-y-2 transition-all duration-200 ${isProductsOpen ? 'block' : 'hidden'}`}>
              <Link to="/products/indoor" className="block py-1">Indoor Cameras</Link>
              <Link to="/products/outdoor" className="block py-1">Outdoor Cameras</Link>
              <Link to="/products/accessories" className="block py-1">Accessories</Link>
            </div>
            
            <Link to="/about" className="nav-link">About Us</Link>
            <Link to="/blog" className="nav-link">Blog</Link>
            <Link to="/support" className="nav-link">Support</Link>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Navbar;