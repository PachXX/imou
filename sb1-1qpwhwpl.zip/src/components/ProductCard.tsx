import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingCart } from 'lucide-react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  return (
    <div className="product-card">
      <Link to={`/product/${product.id}`}>
        <div className="overflow-hidden">
          <img 
            src={product.image} 
            alt={product.name} 
            className="w-full h-48 object-contain hover:scale-105 transition-transform duration-500"
          />
        </div>
        <div className="p-4">
          <h3 className="text-lg font-medium mb-1 hover:text-[#0066cc] transition-colors">{product.name}</h3>
          <p className="text-sm text-gray-600 mb-2">{product.shortDescription}</p>
          <div className="flex justify-between items-center mt-4">
            <span className="font-semibold text-lg">${product.price.toFixed(2)}</span>
            <button className="bg-[#0066cc] text-white p-2 rounded-full hover:bg-blue-700 transition-colors">
              <ShoppingCart size={18} />
            </button>
          </div>
        </div>
      </Link>
    </div>
  );
};

export default ProductCard;