import React from 'react';
import { Link } from 'react-router-dom';
import { Mail, Phone, MapPin, Facebook, Twitter, Instagram, Youtube } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-[#0066cc] text-white pt-12 pb-6">
      <div className="container-custom">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Column 1 - About */}
          <div>
            <h3 className="text-xl font-semibold mb-4">IMOU</h3>
            <p className="text-sm text-blue-100 mb-6">
              Smart security solutions for home and business. Our advanced camera systems provide peace of mind and protection for what matters most.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-white hover:text-blue-200 transition-colors">
                <Facebook size={20} />
              </a>
              <a href="#" className="text-white hover:text-blue-200 transition-colors">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-white hover:text-blue-200 transition-colors">
                <Instagram size={20} />
              </a>
              <a href="#" className="text-white hover:text-blue-200 transition-colors">
                <Youtube size={20} />
              </a>
            </div>
          </div>

          {/* Column 2 - Products */}
          <div>
            <h3 className="text-xl font-semibold mb-4">Products</h3>
            <ul className="space-y-2 text-blue-100">
              <li><Link to="/products/indoor" className="hover:text-white transition-colors">Indoor Cameras</Link></li>
              <li><Link to="/products/outdoor" className="hover:text-white transition-colors">Outdoor Cameras</Link></li>
              <li><Link to="/products/wifi" className="hover:text-white transition-colors">Wi-Fi Cameras</Link></li>
              <li><Link to="/products/ptz" className="hover:text-white transition-colors">PTZ Cameras</Link></li>
              <li><Link to="/products/accessories" className="hover:text-white transition-colors">Accessories</Link></li>
            </ul>
          </div>

          {/* Column 3 - Support */}
          <div>
            <h3 className="text-xl font-semibold mb-4">Support</h3>
            <ul className="space-y-2 text-blue-100">
              <li><Link to="/support/faq" className="hover:text-white transition-colors">FAQ</Link></li>
              <li><Link to="/support/download" className="hover:text-white transition-colors">Download Center</Link></li>
              <li><Link to="/support/warranty" className="hover:text-white transition-colors">Warranty</Link></li>
              <li><Link to="/support/contact" className="hover:text-white transition-colors">Contact Us</Link></li>
              <li><Link to="/privacy-policy" className="hover:text-white transition-colors">Privacy Policy</Link></li>
            </ul>
          </div>

          {/* Column 4 - Contact */}
          <div>
            <h3 className="text-xl font-semibold mb-4">Contact Us</h3>
            <ul className="space-y-3 text-blue-100">
              <li className="flex items-start">
                <MapPin size={20} className="mr-2 mt-1 flex-shrink-0" />
                <span>123 Security Street, Tech City, 10001</span>
              </li>
              <li className="flex items-center">
                <Phone size={20} className="mr-2 flex-shrink-0" />
                <span>+1 (800) 555-1234</span>
              </li>
              <li className="flex items-center">
                <Mail size={20} className="mr-2 flex-shrink-0" />
                <span>info@imou-example.com</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Newsletter */}
        <div className="mt-12 mb-8 p-6 bg-blue-700 rounded-lg">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="mb-4 md:mb-0">
              <h4 className="text-xl font-semibold">Subscribe to our Newsletter</h4>
              <p className="text-blue-100">Stay updated with the latest products and offers</p>
            </div>
            <div className="w-full md:w-auto">
              <form className="flex">
                <input 
                  type="email" 
                  placeholder="Your email address" 
                  className="px-4 py-2 rounded-l-md w-full md:w-64 text-gray-800 focus:outline-none" 
                />
                <button 
                  type="submit" 
                  className="bg-[#ff6600] hover:bg-orange-500 px-4 py-2 rounded-r-md transition-colors"
                >
                  Subscribe
                </button>
              </form>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="pt-8 mt-8 border-t border-blue-500 text-center text-blue-100 text-sm">
          <p>© {new Date().getFullYear()} IMOU. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;